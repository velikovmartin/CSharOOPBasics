﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Moods
{
    public class Happy : Mood
    {
        public override string Name => "Happy";
    }
}
