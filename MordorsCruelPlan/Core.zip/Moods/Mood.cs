﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Moods
{
    public abstract class Mood
    {
        public virtual string Name => "Mood";
    }
}
