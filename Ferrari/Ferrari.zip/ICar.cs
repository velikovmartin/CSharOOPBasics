﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrari
{
    public interface ICar
    {
        string UseBrakes();
        string PushGas();
    }
}
