﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_JediGalaxy
{
    public class Player
    {
        private int dimOne;
        private int dimTwo;

        public int DimOne
        {
            get { return dimOne; }
            set { dimOne = value; }
        }

        public int DimTwo
        {
            get { return dimTwo; }
            set { dimTwo = value; }
        }

    }
}
