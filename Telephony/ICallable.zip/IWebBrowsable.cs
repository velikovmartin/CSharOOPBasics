﻿using System;

namespace Telephony
{
    public interface IWebBrowsable
    {
        void Browse(string url);
    }
}
