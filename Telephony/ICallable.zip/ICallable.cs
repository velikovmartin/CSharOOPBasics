﻿using System;

namespace Telephony
{
    public interface ICallable
    {
        void Call(string number);
    }
}
