﻿using BorderControl.Contracts;

namespace BorderControl
{
    class Citizen : IIdentifiable
    {
        private string name;
        private string id;
        private int age;

        public Citizen(string name, int age, string id)
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
        }

        public string Name
        {
            get { return name; }
            private set { name = value; }
        }

        public string Id
        {
            get { return id; }
            private set { id = value; }
        }

        public int Age
        {
            get { return age; }
            private set { age = value; }
        }

    }
}
